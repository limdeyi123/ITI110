import os
# from app import app
import urllib.request
import requests
from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
import cv2
import numpy as np
import json
from json import JSONEncoder

UPLOAD_FOLDER = 'static/uploads/'

app = Flask(__name__)
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024


# tensorflow_server_url = "http://172.17.0.2:8501/"
tensorflow_server_url = "http://localhost:8501/"
url = tensorflow_server_url + 'v1/models/model/versions/1:predict'
headers = {'Content-Type': 'application/json'}

ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
	
@app.route('/')
def upload_form():
	return render_template('upload.html')

@app.route('/', methods=['POST'])
def upload_image():
	if 'file' not in request.files:
		flash('No file part')
		return redirect(request.url)
	file = request.files['file']

	if file.filename == '':
		flash('No image selected for uploading')
		return redirect(request.url)
	if file and allowed_file(file.filename):
		filename = secure_filename(file.filename)
		print('filename is' + filename)
		file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

		# img = cv2.imread('uploads/' + filename)
		img = cv2.imread(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		# predict_result = predict(img)

		cropped_img = crop_centre(img)
		resized_img = cv2.resize(cropped_img, (128, 128), interpolation=cv2.INTER_CUBIC)

		img_array = np.array(resized_img)
		img_array = img_array.reshape((1,) + img_array.shape)
		img_array_list = img_array.tolist()
		json_str = json.dumps(img_array_list)

		data = {"instances": img_array_list ,}

		print(type(json_str))
		response = requests.post(url=url, headers=headers, json=data)

		# If successful
		if response.status_code == 200:
			# Retrieve the response and send it back as-is to
			# the calling application.
			#
			print('JSON POST successful')
			y = response.json()
			# y_str = str(json.dumps(y))

			pred_value = y['predictions'][0][0]
			print(pred_value, type(pred_value))

			if pred_value >= 0.5:
				pred_result = 'PASS'
			else:
				pred_result = 'DEFECT'


		#print('upload_image filename: ' + filename)

		flash('Image successfully uploaded and displayed below. result is '+ pred_result)


		return render_template('upload.html', filename=filename)
	else:
		flash('Allowed image types are -> png, jpg, jpeg, gif')
		return redirect(request.url)

@app.route('/display/<filename>')
def display_image(filename):
	#print('display_image filename: ' + filename)
	return redirect(url_for('static', filename='uploads/' + filename), code=301)

################################################
def crop_centre(img):
	img_y = img.shape[0]
	img_x = img.shape[1]

	img_x_new1 = int((img_x - img_y) / 2)
	img_x_new2 = int(img_y + img_x_new1)

	img_y_new1 = int((img_y - img_x) / 2)
	img_y_new2 = int(img_x + img_y_new1)

	if img_x > img_y:
		cropped_img = img[0:img_y, img_x_new1:img_x_new2]
	elif img_x < img_y:
		cropped_img = img[img_y_new1:img_y_new2, 0:img_x]
	else:
		cropped_img = img

	return cropped_img


# @app.route('/predict', methods=['POST'])
# def predict(img):
# 	# img = cv2.imread('uploads/' + filename)
#
# 	cropped_img = crop_centre(img)
# 	resized_img = cv2.resize(cropped_img, (128, 128), interpolation=cv2.INTER_CUBIC)
#
# 	img_array = np.array(resized_img)
# 	img_array = img_array.reshape((1,) + img_array.shape)
# 	# print(img_array)
# 	img_array_list = img_array.tolist()
# 	json_str = json.dumps(img_array_list)
#
# 	data = {
# 		'instances': [json_str]
# 	}
#
# 	# body = json.JSONEncoder('instances',json_str)
#
# 	# In this deployment, we are not using file uploads.
# 	# Instead we will extract JSON directly from the body,
# 	# which makes things a little easier.
# 	#
# 	# x = request.get_json()
#
# 	# TODO:
# 	# Set the IP address of the Docker container with the tensorflow/serving
# 	# image to connect to.
# 	#
# 	url = tensorflow_server_url + 'v1/models/model/versions/1:predict'
#
# 	# Set the headers
# 	#
# 	headers = {'Content-Type': 'application/json'}
#
# 	# POST our JSON coming from the client application
# 	# to the tensorflow/serving container.
# 	#
# 	response = requests.post(url=url, headers=headers, json=data);
#
# 	# If successful
# 	if response.status_code == 200:
# 		# Retrieve the response and send it back as-is to
# 		# the calling application.
# 		#
# 		print('JSON POST successful')
# 		y = response.json()
# 		print(json.dumps(y))
# 		return Response(json.dumps(y), mimetype='application/json')
#
# 	return Response("{}", mimetype='application/json')

###################################################################

if __name__ == "__main__":
    app.run(debug=True, host= '0.0.0.0')